# 大纲卡 · Android 伴生 App（POC）

这是「手机端同款编辑器 + 只读汇总页 + 同步」的第一阶段：**只读验证**。

## 它现在能做什么

- 通过 AnkiDroid content provider 读取「大纲卡」笔记（note type）；
- 显示每张卡的 question、块数、tags；
- 触发 AnkiDroid 同步；
- 支持 `ocapp://summary?tag=tlc` 的入口（tag 汇总页下一步实现）。

## 为什么需要它

AnkiDroid 的卡片模板 JS 不能写 note 字段，也不能查整个 collection。这个 App 用 AnkiDroid 的 content provider 补上这两件事；复习仍然在 AnkiDroid。

## 如何构建 APK（推荐：GitHub Actions）

1. 新建一个 GitHub 仓库；
2. 把本目录（`android-outline-app/`）里的所有文件上传到仓库根目录；
3. 打开仓库的 **Actions → Build debug APK → Run workflow**；
4. 等构建完成，在 run 页面下载 **outline-companion-debug** artifact；
5. 解压得到 `app-debug.apk`，传到手机安装（允许未知来源）。

> 不需要在电脑上装 Android SDK；GitHub Actions 会装 JDK/Android SDK/Gradle 并编译。

## 本地构建（可选：Android Studio）

1. 用 Android Studio 打开本目录；
2. 等 Gradle 同步完成；
3. Run / Build APK；
4. 安装到手机。

## 手机前置设置

1. AnkiDroid → 设置 → 高级 → **启用 AnkiDroid API**；
2. 允许安装未知来源应用；
3. 打开 App，授予 `READ_WRITE_DATABASE` 权限（会弹窗）；
4. 点「读取大纲卡笔记」。

## 数据安全

- 当前版本**只读**，不会改任何笔记；
- 写入功能会在只读验证通过后，先对一张测试卡启用；
- 桌面已有备份与 `大纲卡-同步故障备份-20261108.apkg`。

## 下一步

1. 只读验证（本版本）；
2. 写入测试卡 → AnkiDroid 同步 → 桌面确认；
3. 接入同款卡片编辑器；
4. 接入只读汇总页（从 note/tag 实时生成）。
