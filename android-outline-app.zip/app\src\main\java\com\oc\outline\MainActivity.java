package com.oc.outline;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * POC companion app.
 *
 * First milestone: read-only access to 大纲卡 notes through the AnkiDroid
 * content provider. Writing and the editor/summary screens come after this
 * read path is verified on a real phone.
 */
public class MainActivity extends Activity {

    private static final String ANKI_PKG = "com.ichi2.anki";
    private static final String AUTHORITY = ANKI_PKG + ".flashcards";
    private static final String PERM = ANKI_PKG + ".permission.READ_WRITE_DATABASE";

    private WebView web;
    private String pendingTag = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.addJavascriptInterface(new Bridge(), "OCApp");

        setContentView(web);

        if (checkSelfPermission(PERM) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{PERM}, 1);
        }

        web.loadUrl("file:///android_asset/index.html");
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri u = intent.getData();
        if (!"ocapp".equals(u.getScheme())) return;
        String tag = u.getQueryParameter("tag");
        if (tag != null) {
            pendingTag = tag;
            if (web != null) {
                final String js = "window.ocOpenTag && window.ocOpenTag(" + JSONObject.quote(tag) + ")";
                web.post(new Runnable() {
                    @Override
                    public void run() {
                        web.evaluateJavascript(js, null);
                    }
                });
            }
        }
    }

    private class Bridge {
        @JavascriptInterface
        public String listNotes() {
            return queryNotes();
        }

        @JavascriptInterface
        public String pendingTag() {
            return pendingTag;
        }

        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void syncAnki() {
            try {
                Intent i = new Intent("com.ichi2.anki.DO_SYNC");
                i.setPackage(ANKI_PKG);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                toast("同步触发失败: " + e.getMessage());
            }
        }
    }

    private String queryNotes() {
        JSONObject result = new JSONObject();
        try {
            ContentResolver cr = getContentResolver();

            long mid = -1;
            String[] fieldNames = null;
            Uri models = Uri.parse("content://" + AUTHORITY + "/models");
            Cursor mc = cr.query(models, null, null, null, null);
            if (mc != null) {
                int idIdx = mc.getColumnIndex("_id");
                int nameIdx = mc.getColumnIndex("name");
                int fnIdx = mc.getColumnIndex("field_names");
                while (mc.moveToNext()) {
                    String name = nameIdx >= 0 ? mc.getString(nameIdx) : "";
                    if ("大纲卡".equals(name)) {
                        mid = mc.getLong(idIdx);
                        String fn = fnIdx >= 0 ? mc.getString(fnIdx) : "";
                        fieldNames = fn.split("\u001f", -1);
                        break;
                    }
                }
                mc.close();
            }

            if (mid < 0) {
                result.put("error", "找不到“大纲卡”笔记类型（请先在桌面同步该 note type）");
                return result.toString();
            }

            Uri notesV2 = Uri.parse("content://" + AUTHORITY + "/notes_v2");
            Uri notes = Uri.parse("content://" + AUTHORITY + "/notes");
            Cursor nc = null;
            try {
                nc = cr.query(notesV2, null, "mid = ?", new String[]{String.valueOf(mid)}, null);
            } catch (Exception ignored) {
                nc = null;
            }
            if (nc == null) {
                nc = cr.query(notes, null, "note:\"大纲卡\"", null, null);
            }
            if (nc == null) {
                result.put("error", "查询 notes 返回 null");
                return result.toString();
            }

            JSONArray arr = new JSONArray();
            int idIdx = nc.getColumnIndex("_id");
            int fldsIdx = nc.getColumnIndex("flds");
            int tagsIdx = nc.getColumnIndex("tags");
            while (nc.moveToNext()) {
                long nid = nc.getLong(idIdx);
                String flds = fldsIdx >= 0 ? nc.getString(fldsIdx) : "";
                String tags = tagsIdx >= 0 ? nc.getString(tagsIdx) : "";
                String[] vals = flds.split("\u001f", -1);

                JSONObject note = new JSONObject();
                note.put("nid", nid);
                note.put("tags", tags);

                JSONObject fields = new JSONObject();
                for (int i = 0; i < vals.length; i++) {
                    String key = (fieldNames != null && i < fieldNames.length) ? fieldNames[i] : ("f" + i);
                    fields.put(key, vals[i]);
                }
                note.put("fields", fields);
                arr.put(note);
            }
            nc.close();

            result.put("count", arr.length());
            result.put("notes", arr);
        } catch (Exception e) {
            try {
                result.put("error", e.toString());
            } catch (JSONException ignored) {
                // ignore
            }
        }
        return result.toString();
    }
}
